library(testthat)
library(lanalytics)

#test_check("lanalytics")
